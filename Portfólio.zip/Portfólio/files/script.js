// ============================================================
//  PORTFÓLIO — SCRIPT PRINCIPAL
//  script.js
//
//  REQUISITOS ATENDIDOS:
//  R1 - Página HTML com CSS e script.js vinculado
//  R2 - Seção 'Sobre mim' com variáveis JS
//  R3 - Cálculos com operadores
//  R4 - Estrutura condicional (quiz, validação)
//  R5 - Lista dinâmica com laço de repetição
//  R6 - Array de objetos renderizado
//  R7 - Funções nomeadas (>3)
//  R8 - Formulário com validação JS
//  R9 - Chamada API externa com fetch
//  R10 - Comentários explicativos (>10 comentários)
//  R11 - Apresentação oral (descrita no README)
// ============================================================

// ============================================================
//  ██████╗  █████╗ ██████╗  ██████╗  ███████╗
//  ██╔══██╗██╔══██╗██╔══██╗██╔═══██╗██╔════╝
//  ██║  ██║███████║██║  ██║██║   ██║███████╗
//  ██║  ██║██╔══██║██║  ██║██║   ██║╚════██║
//  ██████╔╝██║  ██║██████╔╝╚██████╔╝███████║
//  ╚═════╝ ╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚══════╝
//
//  ↓↓↓  EDITE SEUS DADOS ABAIXO  ↓↓↓
// ============================================================

// R2 — Dados pessoais via variáveis JS
const nome = "Antonio Cortez Neto";
const curso = "Análise e Desenvolvimento de Sistemas";
const anoNascimento = 2003;
const anoIniCurso = 2025; // ano em que começou o módulo
const bio = "Garoto de Programa, quero um emprego pelo amor de DEUS.";

// Notas para cálculo de média (R3)
const notas = [10, 9.0, 9.0, 9.0];

// ============================================================
//  IMAGENS DE FUNDO
const bgImages = [
  "assets/backgrounds/fnaf1.webp",
];

// ============================================================
//  HABILIDADES — R6 (array de objetos)
// ============================================================
const habilidades = [
  { nome: "HTML5", nivel: 90 },
  { nome: "CSS3", nivel: 85 },
  { nome: "JavaScript", nivel: 75 },
  { nome: "Git", nivel: 70 },
  { nome: "Node.js", nivel: 50 },
  { nome: "Python", nivel: 45 },
  // Adicione mais habilidades aqui...
];

// ============================================================
//  PROJETOS — R6 (array de objetos)
// ============================================================
const projetos = [
  {
    nome: "Projeto 01 — Sistema de Estacionamento",
    descricao: "Sistema em TKinter para controle de vagas, desenvolvido durante o módulo.",
    tags: ["Python", "TKinter", "SQLite"],
    link: "https://github.com/Antonio-Cortez-231/Sistema-de-Estacionamento",
  },
  {
    nome: "Projeto 02 — Chatbot de Suporte para Restaurante",
    descricao: "Chatbot desenvolvido para atender clientes de um restaurante, com integração a API de reservas.",
    tags: ["JavaScript", "API", "Fetch"],
    link: "https://github.com/Antonio-Cortez-231/Chatbot_de_suporte_restaurante",
  },
  // Adicione mais projetos aqui...
];

// ============================================================
//  SEQUÊNCIA DE BOOT
// ============================================================
const bootLines = [
  "BIOS v2.1.4 — FODA-SE EDITION",
  "Verificando empregos... [NÃO EXISTEM]",
  "Iniciando drivers... [OK]",
  "Montando sistema de arquivos... [CORROMPIDO]",
  "AVISO: Seus currículos nem sequer foram vistos. Otário",
  "Carregando interface...",
  ">>> ACESSO CONCEDIDO <<<",
  ">>> REDIRECIONANDO PARA PORTFÓLIO <<<",
  "",
  "Iniciando carregamento...",
];

// ============================================================
//  FUNÇÕES NOMEADAS — R7 (mínimo 3)
// ============================================================

// Função 1: Calcular idade (R3 — operadores aritméticos)
function calcularIdade(anoNasc) {
  const anoAtual = new Date().getFullYear();
  return anoAtual - anoNasc; // operador de subtração
}

// Função 2: Calcular média das notas (R3 — operadores + laço)
function calcularMedia(arr) {
  let soma = 0;
  for (let i = 0; i < arr.length; i++) {
    soma += arr[i]; // operador de adição acumulada
  }
  return (soma / arr.length).toFixed(1); // operador de divisão
}

// Função 3: Calcular tempo de curso em meses (R3 — operadores)
function calcularTempoCurso(anoInicio) {
  const anoAtual = new Date().getFullYear();
  const mesAtual = new Date().getMonth() + 1;
  const mesesTotal = (anoAtual - anoInicio) * 12 + mesAtual; // aritmética
  return mesesTotal;
}

// Função 4: Renderizar habilidades (R5 — laço de repetição, R6 — array de objetos)
function renderizarHabilidades() {
  const container = document.getElementById("skills-container");
  container.innerHTML = ""; // limpa o container

  // R5 — laço de repetição com forEach
  habilidades.forEach(function (skill) {
    const card = document.createElement("div");
    card.classList.add("skill-card");
    card.innerHTML = `
      <span class="skill-name">${skill.nome}</span>
      <div class="skill-bar-bg">
        <div class="skill-bar-fill" data-nivel="${skill.nivel}"></div>
      </div>
      <span class="skill-pct">${skill.nivel}%</span>
    `;
    container.appendChild(card);
  });

  // Anima as barras após inserir no DOM
  setTimeout(function () {
    document.querySelectorAll(".skill-bar-fill").forEach(function (bar) {
      bar.style.width = bar.dataset.nivel + "%";
    });
  }, 200);
}

// Função 5: Renderizar projetos (R5 — laço, R6 — array de objetos)
function renderizarProjetos() {
  const container = document.getElementById("projetos-container");
  container.innerHTML = "";

  // R5 — laço for...of para iterar o array
  for (const projeto of projetos) {
    const tagsHtml = projeto.tags
      .map(t => `<span class="tag">${t}</span>`)
      .join("");

    const item = document.createElement("div");
    item.classList.add("projeto-item");
    item.innerHTML = `
      <p class="projeto-nome">
        <span style="color:var(--red)">▶</span>
        <a href="${projeto.link}" style="color:var(--yellow); text-decoration:none;">${projeto.nome}</a>
      </p>
      <p class="projeto-desc">${projeto.descricao}</p>
      <div class="projeto-tags">${tagsHtml}</div>
    `;
    container.appendChild(item);
  }
}

// Função 6: Preencher dados do "Sobre mim" com variáveis (R2, R3)
function preencherSobre() {
  const idade = calcularIdade(anoNascimento);       // R3 — cálculo de idade
  const media = calcularMedia(notas);               // R3 — cálculo de média
  const meses = calcularTempoCurso(anoIniCurso);    // R3 — cálculo de tempo

  // R4 — condicional: classifica a média
  let classificacao;
  if (media >= 9.0) {
    classificacao = "[ EXCELENTE ]";
  } else if (media >= 7.0) {
    classificacao = "[ APROVADO ]";
  } else {
    classificacao = "[ RECUPERAÇÃO ]";
  }

  // Inserindo os dados calculados no DOM
  document.getElementById("nome-output").textContent = nome;
  document.getElementById("curso-output").textContent = curso;
  document.getElementById("idade-output").textContent = idade + " anos";
  document.getElementById("bio-output").textContent = bio;
  document.getElementById("tempo-curso-output").textContent = meses + " meses";
  document.getElementById("media-output").textContent = media + " " + classificacao;
}

// Função 7: Validar e enviar formulário (R8 — validação JS)
function enviarFormulario() {
  // Pega os valores dos campos
  const nomeCampo = document.getElementById("form-nome").value.trim();
  const emailCampo = document.getElementById("form-email").value.trim();
  const msgCampo = document.getElementById("form-msg").value.trim();

  let valido = true; // flag de controle (R4 — condicional)

  // Limpa mensagens de erro anteriores
  document.getElementById("err-nome").textContent = "";
  document.getElementById("err-email").textContent = "";
  document.getElementById("err-msg").textContent = "";
  document.getElementById("form-sucesso").textContent = "";

  // R4 — validações condicionais
  if (nomeCampo === "") {
    document.getElementById("err-nome").textContent = "❌ Nome obrigatório.";
    valido = false;
  }

  // Valida formato de email com expressão regular
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(emailCampo)) {
    document.getElementById("err-email").textContent = "❌ Email inválido.";
    valido = false;
  }

  if (msgCampo.length < 10) {
    document.getElementById("err-msg").textContent = "❌ Mensagem muito curta (mínimo 10 caracteres).";
    valido = false;
  }

  // Se tudo válido, exibe mensagem de sucesso
  if (valido) {
    document.getElementById("form-sucesso").textContent =
      "✔ MENSAGEM TRANSMITIDA COM SUCESSO. CRIPTOGRAFIA APLICADA.";
    // Limpa os campos após envio
    document.getElementById("form-nome").value = "";
    document.getElementById("form-email").value = "";
    document.getElementById("form-msg").value = "";
  }
}

// Função 8: Buscar frase na API externa (R9 — fetch)
function buscarFrase() {
  const quoteEl = document.getElementById("api-quote");
  quoteEl.textContent = "Interceptando canal externo...";
  quoteEl.classList.add("blink-slow");

  // R9 — chamada à API pública com fetch()
  fetch("https://api.adviceslip.com/advice", { cache: "no-cache" })
    .then(function (response) {
      return response.json(); // converte resposta para JSON
    })
    .then(function (data) {
      // R4 — condicional: verifica se os dados vieram corretamente
      if (data && data.slip && data.slip.advice) {
        quoteEl.textContent = '"' + data.slip.advice + '"';
      } else {
        quoteEl.textContent = "[ERRO: dados não encontrados no servidor]";
      }
      quoteEl.classList.remove("blink-slow");
    })
    .catch(function (erro) {
      // Trata erros de rede
      quoteEl.textContent = "[ERRO DE CONEXÃO: " + erro.message + "]";
      quoteEl.classList.remove("blink-slow");
    });
}

// Função 9: Verificar resposta do quiz (R4 — condicional)
function verificarResposta(botao, correto) {
  const botoesTodos = document.querySelectorAll(".quiz-btn");
  const resultado = document.getElementById("quiz-resultado");

  // Desativa todos os botões após resposta
  botoesTodos.forEach(function (btn) {
    btn.disabled = true;
  });

  // R4 — condicional: resposta certa ou errada
  if (correto) {
    botao.classList.add("correct");
    resultado.textContent = "✔ CORRETO. ACESSO PARCIALMENTE RESTAURADO.";
    resultado.style.color = "var(--green)";
  } else {
    botao.classList.add("wrong");
    resultado.textContent = "✘ INCORRETO. ARQUIVOS SERÃO DELETADOS EM 3... 2... 1...";
    resultado.style.color = "var(--red)";
  }
}

// ============================================================
//  TIMER REGRESSIVO (estética ransomware)
// ============================================================
function iniciarTimer() {
  // Tempo inicial em segundos (aqui: 23 horas, 59 min)
  let total = 23 * 3600 + 59 * 60 + 0;

  function atualizar() {
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;
    const fmt = n => String(n).padStart(2, "0");
    document.getElementById("countdown-timer").textContent =
      fmt(h) + ":" + fmt(m) + ":" + fmt(s);
    if (total > 0) total--;
  }

  atualizar();
  setInterval(atualizar, 1000);
}

// ============================================================
//  BOOT SEQUENCE ANIMATION
// ============================================================
function executarBoot(callback) {
  const bootEl = document.getElementById("boot-text");
  let texto = "";
  let i = 0;

  // Exibe cada linha do boot com delay
  function exibirLinha() {
    if (i >= bootLines.length) {
      setTimeout(function () {
        document.getElementById("boot-screen").style.opacity = "0";
        document.getElementById("boot-screen").style.transition = "opacity 0.8s";
        setTimeout(function () {
          document.getElementById("boot-screen").style.display = "none";
          document.getElementById("main-content").style.display = "block";
          callback();
        }, 800);
      }, 500);
      return;
    }
    texto += bootLines[i] + "\n";
    bootEl.textContent = texto;
    i++;
    // Delay variável para efeito realista
    const delay = bootLines[i - 1] === "" ? 100 : 180 + Math.random() * 120;
    setTimeout(exibirLinha, delay);
  }

  exibirLinha();
}

// ============================================================
//  NOISE CANVAS (estática de TV)
// ============================================================
function initNoise() {
  const canvas = document.getElementById("noise-canvas");
  const ctx = canvas.getContext("2d");

  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }

  function drawNoise() {
    const w = canvas.width;
    const h = canvas.height;
    const imageData = ctx.createImageData(w, h);
    const data = imageData.data;

    // Gera ruído aleatório pixel a pixel
    for (let i = 0; i < data.length; i += 4) {
      const v = Math.random() * 255;
      data[i] = v; // R
      data[i + 1] = v; // G
      data[i + 2] = v; // B
      data[i + 3] = 255;
    }

    ctx.putImageData(imageData, 0, 0);
    requestAnimationFrame(drawNoise);
  }

  resize();
  window.addEventListener("resize", resize);
  drawNoise();
}

// ============================================================
//  IMAGENS DE FUNDO (configura e alterna)
// ============================================================
function initBackground() {
  // R4 — condicional: só ativa se houver imagens configuradas
  if (bgImages.length === 0) return;

  const bgEl = document.getElementById("bg-image");
  let idx = 0;

  function trocarBackground() {
    bgEl.style.backgroundImage = `url('${bgImages[idx]}')`;
    bgEl.style.opacity = "1";
    idx = (idx + 1) % bgImages.length; // R3 — operador módulo para loop
  }

  trocarBackground();
  // Troca a imagem a cada 15 segundos
  setInterval(trocarBackground, 15000);
}

// ============================================================
//  NAVEGAÇÃO (scroll suave para seções)
// ============================================================
function initNav() {
  const botoesNav = document.querySelectorAll(".nav-btn");

  // R5 — laço para adicionar evento em cada botão de nav
  botoesNav.forEach(function (btn) {
    btn.addEventListener("click", function () {
      const target = btn.dataset.target;
      const el = document.getElementById(target);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });
}

// ============================================================
//  EFEITO DE TEXTO GLITCH PERIÓDICO NO TÍTULO
// ============================================================
function initGlitchExtra() {
  const titulo = document.getElementById("main-title");
  const textoOriginal = titulo.textContent;

  const chars = "█▓▒░!@#$%&*?/\\|<>[]{}";

  setInterval(function () {
    // R4 — condicional: 20% de chance de glitchar
    if (Math.random() > 0.2) return;

    let glitched = "";
    for (let i = 0; i < textoOriginal.length; i++) {
      // Substitui caractere aleatoriamente (R3 — operadores lógicos)
      if (Math.random() < 0.1) {
        glitched += chars[Math.floor(Math.random() * chars.length)];
      } else {
        glitched += textoOriginal[i];
      }
    }

    titulo.textContent = glitched;

    // Restaura o texto original após 100ms
    setTimeout(function () {
      titulo.textContent = textoOriginal;
    }, 100);
  }, 2000);
}

// ============================================================
//  INICIALIZAÇÃO PRINCIPAL
// ============================================================
function init() {
  preencherSobre();      // Preenche dados pessoais
  renderizarHabilidades(); // Cria cards de habilidades
  renderizarProjetos();  // Cria lista de projetos
  iniciarTimer();        // Inicia contador regressivo
  initNav();             // Ativa navegação
  initBackground();      // Imagens de fundo (se configuradas)
  initJumpscare();       // Jumpscares (se configurados)
  iniciarMusicaFundo();  // Trilha sonora (se configurada)
  initGlitchExtra();     // Efeito glitch no título
  buscarFrase();         // Busca frase na API ao carregar
  initNoise();           // Ruído de TV
}

// Aguarda o DOM estar pronto, depois executa o boot
document.addEventListener("DOMContentLoaded", function () {
  executarBoot(init);
});
