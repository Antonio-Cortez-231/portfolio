# ☠ PORTFÓLIO — ESTÉTICA RANSOMWARE / CREEPYPASTA ☠

## 📁 Estrutura de Arquivos

```
portfolio/
├── index.html          ← Estrutura principal
├── style.css           ← Estilização (tema dark/horror)
├── script.js           ← Toda a lógica JS
├── README.md           ← Este arquivo
└── assets/             ← Crie esta pasta manualmente
    ├── backgrounds/    ← Imagens de fundo assustadoras
    ├── jumpscares/     ← Imagens de susto
    └── sounds/         ← Trilha sonora e efeitos
```

---

## ✏️ PERSONALIZANDO SEUS DADOS (script.js)

Abra o `script.js` e edite as variáveis no topo do arquivo:

```javascript
const nome = "Seu Nome Aqui";
const curso = "Linguagem de Programação";
const anoNascimento = 2000;
const anoIniCurso = 2024;
const bio = "Sua bio aqui...";
const notas = [8.5, 7.0, 9.0, 8.0]; // suas notas reais
```

---

## 🖼️ ADICIONANDO IMAGENS DE FUNDO

1. Crie a pasta `assets/backgrounds/`
2. Coloque seus arquivos de imagem lá dentro
3. No `script.js`, edite o array `bgImages`:

```javascript
const bgImages = [
  "assets/backgrounds/horror1.jpg",
  "assets/backgrounds/horror2.png",
];
```

As imagens alternam a cada 15 segundos automaticamente.

---

## 👻 ADICIONANDO JUMPSCARES

1. Crie a pasta `assets/jumpscares/`
2. Coloque suas imagens de susto lá
3. No `script.js`, edite o array `jumpscareImages`:

```javascript
const jumpscareImages = [
  "assets/jumpscares/susto1.jpg",
  "assets/jumpscares/susto2.png",
];
```

4. Ajuste a probabilidade (0 a 1):

```javascript
const jumpscareProbability = 0.05; // 5% de chance por clique
```

---

## 🎵 ADICIONANDO SOM

### Trilha sonora de fundo (loop):
No `index.html`, dentro da tag `<audio id="bg-music">`, descomente e edite:

```html
<audio id="bg-music" loop preload="auto">
  <source src="assets/sounds/trilha.mp3" type="audio/mpeg">
</audio>
```

### Som de clique:
```html
<audio id="click-sound" preload="auto">
  <source src="assets/sounds/click.mp3" type="audio/mpeg">
</audio>
```

### Som de susto (jumpscare):
```html
<audio id="jumpscare-sound" preload="auto">
  <source src="assets/sounds/scream.mp3" type="audio/mpeg">
</audio>
```

> ⚠️ Navegadores modernos bloqueiam autoplay de áudio. A trilha começa ao primeiro clique do usuário.

---

## 🏗️ ADICIONANDO PROJETOS

No `script.js`, adicione ao array `projetos`:

```javascript
const projetos = [
  {
    nome: "Meu Projeto",
    descricao: "Descrição do projeto.",
    tags: ["HTML", "CSS", "JS"],
    link: "https://github.com/seu-usuario/projeto",
  },
  // ...
];
```

---

## ⚙️ ADICIONANDO HABILIDADES

```javascript
const habilidades = [
  { nome: "HTML5",      nivel: 90 },
  { nome: "JavaScript", nivel: 75 },
  // ... (nivel de 0 a 100)
];
```

---

## ✅ REQUISITOS ATENDIDOS

| Req | Item | Status |
|-----|------|--------|
| R1 | HTML + CSS + script.js | ✅ |
| R2 | Seção Sobre Mim com variáveis JS | ✅ |
| R3 | Cálculos: idade, meses de curso, média | ✅ |
| R4 | Condicionais: quiz, validação, jumpscare, classificação | ✅ |
| R5 | Listas dinâmicas com laços (forEach, for...of) | ✅ |
| R6 | Arrays de objetos: habilidades e projetos | ✅ |
| R7 | +9 funções nomeadas no código | ✅ |
| R8 | Formulário com validação JS completa | ✅ |
| R9 | Fetch para API externa (adviceslip.com) | ✅ |
| R10 | +30 comentários explicativos no código | ✅ |
| R11 | Apresentação oral (veja dicas abaixo) | ⏳ |

---

## 🎤 DICAS PARA APRESENTAÇÃO ORAL (R11 — 3 minutos)

1. **[0:00-0:30]** Introdução: "Este é meu portfólio com estética de ransomware..."
2. **[0:30-1:00]** Mostre a sequência de boot e explique o conceito criativo
3. **[1:00-1:30]** Explique o código: variáveis JS preenchendo o HTML, os arrays de habilidades/projetos
4. **[1:30-2:00]** Demonstre o quiz (condicional) e a validação do formulário
5. **[2:00-2:30]** Mostre a chamada à API externa com fetch()
6. **[2:30-3:00]** Encerramento: o que aprendeu, o que pode melhorar

---

*☠ Feito com HTML, CSS e JavaScript puro — nenhum arquivo foi realmente criptografado.*
